Extract this archive and run tectonic naacl2027.tex. The evidence commands are in evidence.zip.
