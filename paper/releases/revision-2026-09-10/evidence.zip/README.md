# Palindrome search evidence

This archive contains the saved outputs, frozen inputs, current search source,
and checks for *Sound POS-Constraint Pruning for Two-Ended Palindrome Search*. Paths are
relative to this directory. The audits use Python 3.11 and the standard library;
they do not install packages, download data, or call models.

## Check the saved outputs

```sh
python3 paper/verify_structural_draft.py --output structural-evidence.json
python3 paper/critique_evidence.py --output critique-evidence.json
python3 -m experiments.audit_controlled_pos_pruning data/controlled --output controlled-audit.json
```

The first command checks all 107,500 saved pair rows, the Brown payload counts,
and the dictionary artifact. The second uses a separate bitset checker for
complete POS-shape admission and computes diversity and overlap. Reports are
written to the named files and printed to stdout. The third checks all 2,544
accepted-pair rows from the controlled trials, their counters and hashes, and
the paired subset relation. Do not use Python's `-O` flag: the checks require
assertions.

The controlled result contains 50 fixed-opening paired trials. Terminal and
incremental filtering return 407 and 2,137 accepted pairs. The incremental arm
achieves 5.47 times as many accepted pairs per popped state (paired bootstrap
95% interval 2.89--17.65) and 4.36 times as many per CPU second (2.30--13.93).
It shows no resolved improvement in accepted pairs per generated state: the ratio is 0.95
(0.46--3.20). Every terminal-arm pair is present in its matched incremental
arm. These intervals measure the selected opening searches, not independent
corpora or systems.

The earlier exploratory counts are 20,989 terminal pairs and 86,511 incremental pairs,
including 16,766 shared pairs. The incremental-only subset has 69,745 pairs and
29 junction families; the full incremental arm has 30 families. A family is the
last left token and first right token. It is not an independent replication.
The payload has 49,815 word types, 53,548 word-tag associations, 8,982 raw shapes,
and 5,649 retained shapes. The dictionary artifact has 90,937 letters and 16,168
unique phrases, no adjacent repeated tokens, and at most three uses of any
nonexception token.

## Run the current search

```sh
python3 -m experiments.controlled_pos_pruning --trials 50 --node-budget 50000 --workers 8 --trial-mode openings --opening-min-branches 20 --opening-selection-seed 20260911 --out-dir rerun/controlled
python3 paper/rerun_search.py --shards 32 --seconds-per-arm 600 --node-budget 20000000 --max-hits 10000 --out-dir rerun/structural
python3 -m experiments.norvig_letters --seconds 300 --dynamic --feasible --max-content-uses 3 --out rerun/length
```

The first command is the controlled result. It selects 50 openings from the 85
whose one-word states have at least 20 immediate letter-compatible extensions;
selection uses a fixed hash rank and no POS tags or result data. Both arms use
the same deterministic sibling ordering and at most 50,000 popped states. There
is no elapsed-time or output-count stop. Each arm runs in a fresh process so
peak RSS is independent. Its output includes every accepted pair, per-trial
measurements, stopping reasons, inputs, current source hashes, and environment.

The exploratory structural command starts 32 processes. Each runs terminal then incremental
filtering, with rank seeds 0--31 and the recorded limits: 30,000 requested
vocabulary entries, 20--44 letters, at least three words per half, 18 words per
state, and a 16-letter overhang. The first hit, popped-state, or wall-time limit
ends each arm. Word uniqueness and complete admission are checked at closure.
The command writes individual process results, stopping reasons, the aggregate,
input hashes, source hashes, and the current runtime information.

The dictionary command starts from the default seed without a resume file.
It records current settings and source hashes in `provenance.json`. Its input
hashes are in `result.json`. Python 3.11 is the documented structural runtime;
neither historical search retained a complete environment or source revision.
These commands repeat the settings with the included current implementation.
They cannot reconstruct the missing historical environment or guarantee the
same counts under elapsed-time stopping. Those limits apply to the exploratory
structural and dictionary runs, not the new fixed-work comparison.

For a small execution check, use a fresh output directory:

```sh
python3 paper/rerun_search.py --shards 2 --seconds-per-arm 1 --node-budget 4096 --max-hits 5 --out-dir rerun/smoke
```

## Files and counters

- `inputs/`: frozen Brown payload, vocabulary, dictionary, reference, and original dictionary search.
- `data/structural/aggregate.json`: the two saved pair lists and aggregate counters.
- `data/controlled/`: selected openings, per-trial counters and accepted pairs, summary, report, provenance, and audit.
- `data/length/`: the full dictionary artifact, phrase list, and result record.
- `data/inventory/`: the six individual inventory-policy result records.
- `paper/`: manuscript, checks, portable structural driver, and provenance helper.
- `llm_palindrome/`, `experiments/`, and `server/`: current implementation files used or described by the paper.
- `SOURCE-SNAPSHOT.json`: hashes of every included current source file, plus the build checkout's HEAD and dirty status. The hashes identify the files; HEAD alone does not.
- `MANIFEST-SHA256.json`: hashes of every archive payload file.
- `TERMS.md` and `licenses/`: source attribution and retained upstream terms.

In the controlled run, `states_generated` counts states passing the shared
letter, overhang, and structural bounds before the POS gate; `states_pushed`
counts insertions after that gate; and `states_popped` counts removals from the
frontier. `cpu_seconds` is process time and `peak_rss_mib` is measured in a
fresh process. In the exploratory aggregate, `nodes` counts popped states,
excluding rejected children. `closures` counts
eligible closures of 20--44 letters before midpoint, word-count, uniqueness,
and complete-pattern checks. `state_pruned` counts only POS-shape gate failures;
it excludes overhang, letter, word-count, and join restrictions. `seconds` sums
elapsed wall time across processes, not CPU time. Historical per-process traces,
child-generation costs, and gate-check costs are absent.

The old 4.12 ratio describes exploratory saved outputs. It is not a speedup, a
confidence interval, or evidence of language quality. The controlled result
supports rate claims under its fixed-opening protocol but still does not assess
language quality. The dictionary artifact uses a
different inventory, objective, procedure, and acceptance test. Its length is
not evidence about the POS gate. The paper contains the central counts,
acceptance rules, false-positive example, and comparison limits directly.
