# Frozen paired reversal-cost experiment

Status: **audited**. The saved result contains 36 complete cells: 2 causal
language models × 3 segmentation strategies × 6 target lengths, with 150
saved WikiText-2 spans per length. No sample was retained or rejected based on
its reversed form.

## Main result

Across all conditions, reversing the normalized letters and re-segmenting them
adds **2.14–3.34 bits per letter** relative to applying the same segmenter to
the forward letters. Within-cell paired standard errors are 0.04–0.11. The
largest difference between the two models in a matched strategy/length cell is
0.136 bits per letter.

| Segmenter | Forward coverage | Reversed coverage | GPT-2 cost | SmolLM2-135M cost |
| --- | ---: | ---: | ---: | ---: |
| Unigram | 88.7–90.0% | 49.6–51.3% | 2.98–3.20 | 2.90–3.34 |
| Fewest segments | 90.4–91.5% | 52.3–54.6% | 2.86–3.11 | 2.79–3.23 |
| Greedy longest match | 86.9–88.3% | 49.9–52.8% | 2.23–2.61 | 2.14–2.71 |

Coverage is the fraction of letters placed inside source-vocabulary words of
at least three letters. Cost is the mean paired increase in autoregressive LM
surprisal, in bits per normalized ASCII letter.

Replacing natural casing, punctuation, and boundaries with automatic forward
segmentation costs another 0.79–1.73 bits per letter. The main comparison uses
automatic segmentation on both directions so that this formatting and
re-segmentation cost is not charged to reversal.

## Frozen inputs and revisions

- Seed: `20260911`; target lengths: 20, 30, 40, 60, 80, 120; 150 spans each.
- WikiText-2 raw snapshot: `b08601e04326c79dfdd32d625aee71d232d685c3`.
- Source parquet SHA-256: `e83889baabc497075506f91975be5fac0d45c5290b6b20582c8cd1e853d0c9f7`.
- Vocabulary source: 52,927 lines; filtered vocabulary: 52,793 entries.
- Vocabulary SHA-256: `0831919ec27fe131e8b4b4ad41630c48a37087802dc9a94f94cc57441f91f5e6`.
- GPT-2 revision: `607a30d783dfa663caf39e06633721c8d4cfcd7e`.
- SmolLM2-135M revision: `93efa2f097d58c2a74874c7e644dbc9b0cee75a2`.
- Packages: torch 2.12.0, transformers 4.33.3, pyarrow 25.0.1, wordfreq 3.1.1.

Every text token is scored after one shared model-defined BOS/EOS boundary
token. The exact natural text and normalized letters for all sampled spans are
stored in `results.json`.

## Reproduce and audit

Full model rerun from the repository root:

```sh
python3 experiments/mirror_cost.py \
  --models gpt2 HuggingFaceTB/SmolLM2-135M \
  --strategies unigram fewest greedy \
  --spans 20 30 40 60 80 120 --n 150 \
  --seed 20260911 --batch-size 16 \
  --out rerun/results.json
```

Audit the frozen result without loading language models:

```sh
python3 -m experiments.audit_mirror_cost \
  runs/mirror-cost-2026-09-11/results.json \
  --output rerun/audit.json
```

The audit verifies the factorial design, normalized samples, vocabulary hash
and filtered size, complete segmentations, coverage, means, paired standard
errors, and arithmetic. It does not independently recompute model logits; the
full rerun is required for that stronger check.
