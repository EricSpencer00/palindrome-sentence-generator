# v4 supplementary evidence and reproduction

This archive accompanies `paper/naacl2027.tex`. Extract it at a clean checkout
of the repository root, preserving its paths. It contains the frozen v4
manifest and raw results, v3 comparison used to motivate the adaptive follow-
up, all 66 selected texts and their 32 fixed shuffles, model outputs, source
code, vocabulary/lexicon inputs, and pinned dependency lists. `MANIFEST.sha256`
records each archived file hash.

## Search replay

Use Python 3.10+ and install the package versions recorded in the requirements
files. From the repository root, run:

```sh
python3 experiments/paired_directional_search_resource_sensitivity_20260925.py run \
  --manifest runs/directional-search-resource-sensitivity-20260925/manifest.json \
  --phase confirmatory --output /tmp/replayed-v4.json --workers 6
python3 experiments/analyze_directional_search_resource_sensitivity_20260925.py \
  --manifest runs/directional-search-resource-sensitivity-20260925/manifest.json \
  --results /tmp/replayed-v4.json \
  --static-verifier-summary runs/directional-search-resource-sensitivity-20260925/static-verifier-summary-v4-aws.json \
  --json-output /tmp/v4-summary.json --markdown-output /tmp/v4-summary.md
```

The search runner checks every source hash and the pinned `wordfreq` version
before it runs. Its random seeds, task order, vocabulary, gates, and resource
settings are frozen in the manifest. Execution time can vary by host; no run
in the reported experiment reached its cooperative deadline.

## Language diagnostics

Install `paper/readability-requirements.txt` and the Brown corpus to rerun the
Brown scorer; install `experiments/static-verifier-nuc-requirements.txt` and
use the pinned GPT-2 revision shown in the paper to rerun GPT-2. Example:

```sh
NLTK_DATA=/path/to/nltk_data python3 -m experiments.score_directional_search_brown_20260925 \
  --input runs/directional-search-resource-sensitivity-20260925/static-verifier-input-aws.json \
  --output /tmp/brown-v4.json
HF_HOME=/path/to/hf-cache OMP_NUM_THREADS=4 python3 -m experiments.score_gpt2_static_verifier_aws_20260925 \
  --input runs/directional-search-resource-sensitivity-20260925/static-verifier-input-aws.json \
  --output /tmp/gpt2-v4.json --revision 607a30d783dfa663caf39e06633721c8d4cfcd7e \
  --batch-size 8 --execution-host 'authorized CPU host'
python3 experiments/infer_deepseek_static_verifier_20260925.py \
  --input runs/directional-search-resource-sensitivity-20260925/static-verifier-input-aws.json \
  --output /tmp/deepseek-v4.json --budget-usd 0.20 --interval-seconds 0.75
python3 experiments/summarize_directional_static_verifier_20260925.py \
  --input runs/directional-search-resource-sensitivity-20260925/static-verifier-input-aws.json \
  --brown /tmp/brown-v4.json --gpt2 /tmp/gpt2-v4.json --deepseek /tmp/deepseek-v4.json \
  --output /tmp/static-summary-v4.json
```

These scores are deterministic for the archived inputs and model/corpus
versions. A fresh
DeepSeek V3.2 request requires an authorized Bedrock account and
`experiments/static-verifier-bedrock-requirements.txt`; the archived requests
and responses can be re-parsed without a new call. To obtain new responses,
run the included cost-capped scorer with `--budget-usd 0.20`; Bedrock did not provide a
model seed, so a new response is not guaranteed to match. The reported call
used 11,538 input tokens and 1,410 output tokens. Its estimated cost was USD
0.00976206, computed from recorded usage and published [Bedrock rates](https://aws.amazon.com/bedrock/pricing/).

The outputs are automatic diagnostics, not readability labels. No human
ratings are in this archive.
