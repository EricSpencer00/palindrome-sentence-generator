# NAACL 2027 professor review handoff — v1

This bundle contains the anonymous manuscript PDF and source, reviewer brief,
readiness plan, reproducible diagnostic reports, and a separate first-pass
rating packet. This is the first public release, v1. The paper is titled
*Fragment Penalties Shift Repetition in Exact Palindrome Search*. It reports
360 new matched AWS search jobs and a separate blinded Qwen3 audit. Penalties
remove six named trigrams and increase distinct outputs, while strict structural
acceptance decreases and replacement fragments become common. The new plots
show those intervention results, with paired seed-bootstrap intervals.

No human ratings have been collected. The first-pass 52-item reader packet is
retained unchanged as a historical pilot; it does not contain the 148 distinct
outputs of the new experiment. The old mock review and baseline-provenance
audits are historical context, not assessments of the new results.

## Read the paper

Start with `naacl2027-v1.pdf`. The included TeX source, bibliography, and ACL
style files can rebuild it from this folder with:

```sh
tectonic -X compile --outdir /tmp/naacl2027-review-v1 naacl2027-v1.tex
```

## Optional first-pass rating

Extract `first-person-review-packet-v1.zip` and follow `START-HERE.txt`, or open
the included `reviewer.html` directly. It is a one-file offline page. It
supports pause/resume, saves locally when browser storage is available, and
exports the ratings to JSON. No ratings are transmitted. The export validator
and schema are included beside the page in the ZIP.

The ratings are one author's exploratory pilot, not independent or
confirmatory evidence. The intended reviewer has already seen both Qwen
judges' aggregate scores and one example score, so these ratings are not blind to prior
model results. Rate from the displayed wording alone. Keep the raw export with
the packet and do not open the sealed provenance key before the first rating
pass is complete.

## Evidence archive

The full `v1-reproducibility.zip` is maintained separately in the repository.
It is deliberately not embedded here because it includes the sealed mapping
from opaque review IDs to method and task provenance. Keep it closed until
first-pass ratings are finalized. `SHA256SUMS` covers files in this handoff
folder except itself.
