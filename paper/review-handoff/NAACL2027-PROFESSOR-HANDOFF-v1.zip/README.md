# NAACL 2027 professor review handoff — v1

This bundle contains the anonymous manuscript PDF and source, reviewer brief,
readiness plan, reproducible diagnostic reports, and a separate first-pass
rating packet. This is the first public release, v1. The paper is titled
*Evaluating Exact Palindromes Beyond Word-Order Shuffles*. Its two figures examine
continuous score disagreement, individual shuffle-score spreads, and recurring
fragments across distinct texts. The baseline-provenance audit and its three historical reports are
included. The task grid is not an established generator benchmark; the paper
makes no generation-improvement claim. This revision uses saved evidence and
contains no new experiments or model scoring calls. No human ratings have
been collected. The packet defines letter-level versus word-order palindromes.
The October 2 figures show opposite contrast signs for 28/52 distinct texts,
shuffle ranges crossing zero for 63/66 records, and the trigram `no it a` in
46/52 distinct texts. The all-zero rubric remains supporting context.

## Read the paper

Start with `naacl2027-v1.pdf`. The included TeX source, bibliography, and ACL
style files can rebuild it from this folder with:

```sh
tectonic -X compile --outdir /tmp/naacl2027-review-v1 naacl2027-v1.tex
```

## Optional first-pass rating

Extract `first-person-review-packet-v1.zip` and follow `START-HERE.txt`, or open
the included `reviewer.html` directly. It is a one-file offline page. It
supports pause/resume, saves locally when browser storage is available, and
exports the ratings to JSON. No ratings are transmitted. The export validator
and schema are included beside the page in the ZIP.

The ratings are one author's exploratory pilot, not independent or
confirmatory evidence. The intended reviewer has already seen both Qwen
judges' aggregate scores and one example score, so these ratings are not blind to prior
model results. Rate from the displayed wording alone. Keep the raw export with
the packet and do not open the sealed provenance key before the first rating
pass is complete.

## Evidence archive

The full `v1-reproducibility.zip` is maintained separately in the repository.
It is deliberately not embedded here because it includes the sealed mapping
from opaque review IDs to method and task provenance. Keep it closed until
first-pass ratings are finalized. `SHA256SUMS` covers files in this handoff
folder except itself.
