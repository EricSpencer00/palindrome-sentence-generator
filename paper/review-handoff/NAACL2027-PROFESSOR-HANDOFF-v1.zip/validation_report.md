# Public v1 review packet verification

Packet: `palindrome-v1-pilot-9229cdfdf761dace`. Source input SHA-256: `9229cdfdf761dace9824686bd2f9ed285b30a12c798045995d6fa834e3130bf0`.

All 52 frozen texts, item identifiers, text hashes, and display positions are preserved. The page, answer schema, export filename, and packet metadata identify the public edition as v1. This remains one author's exploratory pilot; no ratings have been collected.

| File | SHA-256 |
| --- | --- |
| `answer.schema.json` | `9db7e46a6817250d16c441a5785cc5d6d0ebe35b87fb4d61e9f3c7bf21206d13` |
| `instructions.md` | `0446e38dfaf2279e34431ff800727f31e0d8ec34031bc41669297cf32754bf92` |
| `reviewer.html` | `2b980ac7f6135ddee436c0687f484230c3a5950104b10c6a47702d62783b723a` |
| `validate_answers.py` | `d6b57cdac7dc97d744ce65a4d4038fa4a8cf479d87e4f0ffef8db7e9fb9a5a24` |
