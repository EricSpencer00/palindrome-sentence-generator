NAACL 2027 static language-model audit supplement

The source manuscript is paper/naacl2027.tex. Start with
experiments/STATIC-LANGUAGE-VERIFIER-20260925.md for the protocol, sources,
limits, and exact rerun commands. The frozen score reports and generated table
are included. Rebuilding Brown controls requires the NLTK Brown Corpus; raw
Brown passages and GPT-2 weights are not redistributed. GPT-2 can be fetched
from the pinned public model revision. Re-running DeepSeek requires authorized
Amazon Bedrock access and may return different choices because the provider
does not expose a deterministic seed. Recorded responses and request-level
token use are preserved for audit.

All source and result files are listed with SHA-256 hashes in
SUPPLEMENT-MANIFEST.json.
The frozen input.json is intentionally excluded because it materializes Brown
passages; the prepare command reconstructs it from the recorded source offsets
and checks the expected passage hashes.
