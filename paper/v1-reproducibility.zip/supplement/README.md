# v1 supplementary evidence and reproduction

The current manuscript is *Methods of Finding Longer, Readable Palindromes*.
It reports a fresh, frozen 360-job AWS experiment: 20 seeds, three length bands,
two search implementations, and penalties 0, 4, and 16 for six previously
identified trigrams. Each arm returns 90/120 exact outputs. Distinct surfaces
increase from 69 to 78, but strict structural acceptance falls from 59/120 to
28/120 and replacement fragments appear in 46/78 distinct penalized texts.

The new protocol, results, quality inventory and responses, and analysis are in
`runs/fragment-penalty-20261002/`. The readable report is
`experiments/FRAGMENT-PENALTY-RESULTS-20261002.md`. Reproduce the new figures
and 20,000 paired seed-bootstrap replicates offline:

```sh
python3 experiments/analyze_fragment_penalty_20261002.py
```

Install the plotting versions in `paper/figure-requirements.txt`. This analysis
needs no AWS account, model weights, or Brown corpus. The figures describe
seed variability within this vocabulary and search family, not human quality.
All 148 distinct candidates receive a separate blinded Qwen3 model rating.
No human ratings or matched published-generator benchmark is provided.

For fresh search on an authorized Linux worker, use
`experiments/fragment-penalty-requirements.txt`. In a separate copied extraction,
move `runs/fragment-penalty-20261002/results.json` to an archival filename,
then run `python3 experiments/fragment_penalty_20261002.py run --workers 32`.
The runner refuses to overwrite results and verifies its source/vocabulary
hashes. Keep original evidence intact. A new hosted audit additionally needs
an explicitly configured private AWS budget and account binding; do not resume
the archived quality result. Exact prompts, model ID, settings, and requests'
hashes are recorded, but the provider does not expose a random seed.

A separate 16-job development length-cap probe is retained in
`runs/length-cap-probe-20261008/`. Its two 804-letter outputs fail the strict
screen and are not readability successes. The cap32 arm cannot reach 800
letters; its zero yield is not a method-performance baseline. Verify offline
with `python3 experiments/verify_length_cap_probe_20261008.py`. The interrupted
checkpoint and unknown uncheckpointed outcomes are preserved. The separate
32-job development sweep is in `runs/fragment-penalty-tuning-20261008/REPORT.md`.
Its longest exact output has824 letters; none of its16 selected texts passes
the strict screen. No optimal setting or readability gain is established.

The older 240-job resource collection and its 52 distinct outputs are retained
as development evidence. They supplied the six target fragments, not new test
outcomes. Their figures and score-sign audit remain reproducible:

```sh
python3 paper/build_diagnostic_figures.py
python3 paper/audit_diagnostic_overlap.py
```

The separate 52-item first-person packet concerns that historical collection,
not the 148 distinct outputs in the new intervention. The baseline-provenance
audits also concern historical claims; they are not reviews of this new experiment.

Author-specific machine names and repository commit IDs are omitted from the
exported run metadata. Source-file hashes, model revisions, and cross-file
reproduction hashes are retained and checked.

## Historical resource-comparison replay

Use Python 3.10+ and install the package versions recorded in the requirements
files. From the repository root, run:

```sh
python3 experiments/paired_directional_search_resource_sensitivity_20260925.py run \
  --manifest runs/directional-search-resource-sensitivity-20260925/manifest.json \
  --phase confirmatory --output /tmp/replayed-v1.json --workers 6
python3 experiments/analyze_directional_search_resource_sensitivity_20260925.py \
  --manifest runs/directional-search-resource-sensitivity-20260925/manifest.json \
  --results /tmp/replayed-v1.json \
  --static-verifier-summary runs/directional-search-resource-sensitivity-20260925/static-verifier-summary-v4-aws.json \
  --json-output /tmp/v1-summary.json --markdown-output /tmp/v1-summary.md
```

The search runner checks every source hash and the pinned `wordfreq` version
before it runs. Its random seeds, task order, vocabulary, gates, and resource
settings are frozen in the manifest. Execution time can vary by host; no run
in the reported experiment reached its cooperative deadline.

## Language diagnostics

Install `paper/readability-requirements.txt` and the Brown corpus to rerun the
Brown scorer; install `experiments/static-verifier-nuc-requirements.txt` and
use the pinned GPT-2 revision shown in the paper to rerun GPT-2. Example:

```sh
NLTK_DATA=/path/to/nltk_data python3 -m experiments.score_directional_search_brown_20260925 \
  --input runs/directional-search-resource-sensitivity-20260925/static-verifier-input-aws.json \
  --output /tmp/brown-v1.json
HF_HOME=/path/to/hf-cache OMP_NUM_THREADS=4 python3 -m experiments.score_gpt2_static_verifier_aws_20260925 \
  --input runs/directional-search-resource-sensitivity-20260925/static-verifier-input-aws.json \
  --output /tmp/gpt2-v1.json --revision 607a30d783dfa663caf39e06633721c8d4cfcd7e \
  --batch-size 8 --execution-host 'authorized CPU host'
python3 experiments/infer_deepseek_static_verifier_20260925.py \
  --input runs/directional-search-resource-sensitivity-20260925/static-verifier-input-aws.json \
  --output /tmp/deepseek-v1.json --budget-usd 0.20 --interval-seconds 0.75
python3 experiments/summarize_directional_static_verifier_20260925.py \
  --input runs/directional-search-resource-sensitivity-20260925/static-verifier-input-aws.json \
  --brown /tmp/brown-v1.json --gpt2 /tmp/gpt2-v1.json --deepseek /tmp/deepseek-v1.json \
  --output /tmp/static-summary-v1.json
```

These scores are deterministic for the archived inputs and model/corpus
versions. A fresh
DeepSeek V3.2 request requires an authorized Bedrock account and
`experiments/static-verifier-bedrock-requirements.txt`; the archived requests
and responses can be re-parsed without a new call. To obtain new responses,
run the included cost-capped scorer with `--budget-usd 0.20`; Bedrock did not provide a
model seed, so a new response is not guaranteed to match. The reported call
used 11,538 input tokens and 1,410 output tokens. Its estimated cost was USD
0.00976206, computed from recorded usage and published [Bedrock rates](https://aws.amazon.com/bedrock/pricing/).

The outputs are automatic diagnostics, not readability labels. No human
ratings are in this archive.

## Qwen 2.5 local-model audit

The archive also contains the frozen Qwen protocols, both runner scripts, the
two saved result JSON files, and the dated results report. These are
success-conditioned diagnostics on the 52 selected candidates. The first
run failed its prespecified Brown-control calibration gate; its candidate
scores are inconclusive. The follow-up is post-hoc, changes control units, and
does not rescore candidates. Neither run provides human ratings or generation
coverage.

The Brown manifest at
`runs/readability-length-stratified-20260925.json` is a privacy-preserving
projection: it retains held-out document IDs, sentence indices, token counts,
and sentence hashes required by the runners, but excludes Brown sentence
surfaces. The licensed Brown corpus itself is not included. Install the
specified NLTK version and Brown corpus locally; the runners reconstruct each
control and verify its text hash before scoring. The sealed candidate key is
rebound to the anonymized study inputs in this archive. The saved Qwen result
files are preserved as historical records and still identify their original
input hashes. Therefore a new run from this archive has a new input fingerprint;
do not try to resume either saved historical run. The exact original and
projected input hashes are listed in `supplement/QWEN-EXPORT-PROVENANCE.json`.

First validate the archive inputs without contacting a model:

```sh
python3 experiments/local_llm_readability_audit_20260926.py --prepare-only
python3 experiments/local_llm_single_sentence_brown_sensitivity_20260926.py --prepare-only
```

To create fresh result records, use the installed exact Qwen model digest in
the saved run metadata and an already available local Ollama endpoint. The
endpoint below is a local forwarded port; configure the SSH destination in
your environment without adding a machine name to the archive:

```sh
python3 experiments/local_llm_readability_audit_20260926.py \
  --base-url http://127.0.0.1:11435 --output /tmp/qwen-audit-replay.json
python3 experiments/local_llm_single_sentence_brown_sensitivity_20260926.py \
  --base-url http://127.0.0.1:11435 --output /tmp/qwen-brown-sensitivity-replay.json
```

These commands make new inference requests. The archived JSON files, rather
than a new inference run, are the exact records underlying the reported
results.

## AWS Qwen3 rubric audit

The archive contains the separate Bedrock Qwen3 32B run, source runner,
offline summarizer, pricing snapshot, and results report. The 244 saved
responses can be re-aggregated without model calls or Brown text:

```sh
python3 experiments/summarize_aws_qwen3_readability_audit_20260926.py \
  --input runs/aws-qwen3-32b-readability-audit-20260926.json
```

This model-specific diagnostic rated all 52 candidates 0/3 on both dimensions;
the candidate and matched-shuffle joint-pass rates were both zero. The small
Brown screen passed 11/12 intact spans and 0/12 shuffles; 7 Brown spans
contained multiple sentences. It provides no human readability estimate or
improvement claim. The archived Brown manifest excludes sentence text; a
licensed local NLTK corpus is required to reconstruct controls from the
protocol. The public archive copy removes AWS request IDs and the credential
and profile identity block. Input-hash transformations are recorded in
`supplement/QWEN-EXPORT-PROVENANCE.json`; the archived historical result is
for offline reanalysis, not for `--resume` or fresh inference. A new Bedrock
run has no provider seed and can return different ratings.

## Archived descriptive cross-tab

`experiments/READABILITY-LENGTH-CONSTRUCTION-RESULTS-20260926.md` reports an
offline stratification of the frozen Brown, GPT-2, and DeepSeek diagnostics
for the 66 selected outputs, plus the 38/54-letter Diana-frame case. It is
descriptive model evidence. Its project-selected length groups establish no
length effect or generation improvement. The 38-letter reference has no
located primary human-rating records. Recreate the
report without network access or inference from the extracted archive root:

```sh
python3 experiments/analyze_readability_length_construction_20260926.py \
  --output /tmp/readability-length-construction-rerun.md
```
