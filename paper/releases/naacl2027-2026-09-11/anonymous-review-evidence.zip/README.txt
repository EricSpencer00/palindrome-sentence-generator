Double-anonymous review evidence. Extract and follow README.md.
