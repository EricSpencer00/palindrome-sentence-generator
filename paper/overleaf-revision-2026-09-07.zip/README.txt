Main document: naacl2027.tex. Compile with XeLaTeX/BibTeX or Tectonic.
Evidence archive retains repository-relative paths. Run python3 experiments/verify_revision.py from its root.
See paper/SOURCE-AUDIT.md for provenance and missing evidence. External corpora are not bundled.
The Overleaf archive contains generated tables and needs no Python.
