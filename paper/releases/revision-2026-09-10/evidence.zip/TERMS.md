# Attribution and terms

The archive combines project code, derived data, and third-party inputs. It is
not offered under a blanket CC0 waiver. Preserve the notices below when using
or redistributing the corresponding material.

- Project source: MIT, with the copyright notice in `licenses/PROJECT-LICENSE.txt`.
- Brown-derived `inputs/brown.json.gz`: W. N. Francis and H. Kucera, Brown
  University. The NLTK Brown README permits redistribution; its package record
  specifies noncommercial use. Both are retained under `licenses/`. The derived
  payload stores observed word tags, sentence shapes, and trigram counts.
  Source: https://github.com/nltk/nltk_data/tree/gh-pages/packages/corpora
- Universal POS mapping: Slav Petrov, Dipanjan Das, and Ryan McDonald (2012),
  *A Universal Part-of-Speech Tagset*, LREC, 2089--2096.
  https://aclanthology.org/L12-1115/
  The upstream mapping README is retained under `licenses/`.
- Vocabulary: derived from wordfreq, Robyn Speer, with upstream data and
  attribution notices in `licenses/WORDFREQ-NOTICE.md`. The data license is
  Creative Commons Attribution-ShareAlike 4.0. The frozen vocabulary is a
  filtered English word list; the payload-building environment was not frozen.
  https://github.com/rspeer/wordfreq
- `inputs/norvig/pal3.py`: Peter Norvig, from pytudes. MIT license retained in
  `licenses/NORVIG-LICENSE.txt`.
  https://github.com/norvig/pytudes/blob/main/py/pal3.py
- `inputs/norvig/npdict.txt`: Peter Norvig's phrase list, derived from Grady
  Ward's Moby Word Lists. The source collection is public domain in the USA.
  https://www.norvig.com/npdict.txt
  https://www.gutenberg.org/ebooks/3201
- `inputs/norvig/pal21txt.html`: Peter Norvig's published version-3 reference,
  retained as a research comparison with its attribution. No new license is
  asserted for that reference. https://www.norvig.com/pal21txt.html

The saved structural outputs and dictionary artifact are supplied for research
verification. Their inclusion does not change the terms of their source inputs.
Copyright and attribution notices remain in the files. A repository's anonymous
preview option hides selected metadata; it does not remove these file notices.
