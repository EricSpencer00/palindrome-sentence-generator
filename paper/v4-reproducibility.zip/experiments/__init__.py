"""Reproducible bounded search experiments."""
