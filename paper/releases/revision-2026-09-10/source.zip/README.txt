Current working paper: eric_evidence_release_draft.md.
Archival typeset revision: naacl2027.tex. Compile it with tectonic --outdir out naacl2027.tex.
The evidence archive retains repository-relative paths. Run python3 paper/validate_release.py --release-id revision-2026-09-10 --compile from the repository root to check archive membership and a clean source build.
External corpora are not bundled. SOURCE-AUDIT.md records input versions, hashes, provenance, and missing evidence.
